/*
 * Copyright (c) 2017-2018, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== NVSI2C24C.c ========
 */

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

#include <ti/drivers/dpl/HwiP.h>
#include <ti/drivers/dpl/SemaphoreP.h>

#include <ti/drivers/NVS.h>
#include <ti/drivers/nvs/NVSI2C24C.h>

#include <ti/drivers/I2C.h>

/* Instruction codes */
#define I2CFLASH_WRITE              0x02 /**< Page Program */
#define I2CFLASH_READ               0x03 /**< Read Data */
#define I2CFLASH_READ_STATUS        0x05 /**< Read Status Register */
#define I2CFLASH_WRITE_ENABLE       0x06 /**< Write Enable */
#define I2CFLASH_SUBSECTOR_ERASE    0x20 /**< SubSector (4K Byte) Erase */
#define I2CFLASH_SECTOR_ERASE       0xD8 /**< Sector (64K Byte) Erase */
#define I2CFLASH_MASS_ERASE         0xC7 /**< Erase entire flash */

#define I2CFLASH_RDP                0xAB /**< Release from Deep Power Down */
#define I2CFLASH_DP                 0xB9 /**< Deep Power Down */

/* Bitmasks of the status register */
#define I2CFLASH_STATUS_BIT_BUSY    0x01 /**< Busy bit of status register */

/* Write page size assumed by this driver */
#define I2CFLASH_PROGRAM_PAGE_SIZE  256

/* highest supported I2C instance index */
#define MAX_I2C_INDEX               3

static int_fast16_t checkEraseRange(NVS_Handle handle, size_t offset, size_t size);
static int_fast16_t doErase(NVS_Handle handle, size_t offset, size_t size);
static int_fast16_t doRead(NVS_Handle handle, size_t offset, void *buffer,
                        size_t bufferSize);
static int_fast16_t doWriteVerify(NVS_Handle handle, size_t offset,
                        void *src, size_t srcBufSize, void *dst,
                        size_t dstBufSize, bool preFlag);

static int_fast16_t extFlashI2CWrite(const uint8_t *buf, size_t len);
static int_fast16_t extFlashI2CRead(uint8_t *buf, size_t len);
static int_fast16_t extFlashPowerDown(NVS_Handle nvsHandle);
static int_fast16_t extFlashPowerStandby(NVS_Handle nvsHandle);
static int_fast16_t extFlashWaitReady(NVS_Handle nvsHandle);
static int_fast16_t extFlashWriteEnable(NVS_Handle nvsHandle);
static int_fast16_t extFlashMassErase(NVS_Handle nvsHandle);

extern NVS_Config NVS_config[];
extern const uint8_t NVS_count;

/* NVS function table for NVSI2C24C implementation */
const NVS_FxnTable NVSI2C24C_fxnTable = {
    NVSI2C24C_close,
    NVSI2C24C_control,
    NVSI2C24C_erase,
    NVSI2C24C_getAttrs,
    NVSI2C24C_init,
    NVSI2C24C_lock,
    NVSI2C24C_open,
    NVSI2C24C_read,
    NVSI2C24C_unlock,
    NVSI2C24C_write
};

/* manage I2C indexes */
static I2C_Handle I2CHandles[MAX_I2C_INDEX + 1];
static uint8_t I2CHandleUsers[MAX_I2C_INDEX + 1];

/*
 * currently active (protected within Semaphore_pend() block)
 * I2C handle, and CSN pin
 */
static I2C_Handle I2CHandle;

/*
 *  Semaphore to synchronize access to flash region.
 */
static SemaphoreP_Handle  writeSem;

/*
 *  ======== NVSI2C24C_close ========
 */
void NVSI2C24C_close(NVS_Handle handle)
{
    NVSI2C24C_HWAttrs const *hwAttrs;
    NVSI2C24C_Object *object;

    SemaphoreP_pend(writeSem, SemaphoreP_WAIT_FOREVER);

    hwAttrs = handle->hwAttrs;
    object = handle->object;

    I2CHandle = object->I2CHandle;

    /* close the I2C if we opened it */
    if (hwAttrs->I2CHandle == NULL) {
        I2CHandleUsers[hwAttrs->I2CIndex] -= 1;

        /* close I2C if this is the last region that uses it */
        if (I2CHandleUsers[hwAttrs->I2CIndex] == 0) {
            // Put the part in low power mode
            extFlashPowerDown(handle);

            I2C_close(object->I2CHandle);
            I2CHandles[hwAttrs->I2CIndex] = NULL;
        }
    }

    object->opened = false;

    SemaphoreP_post(writeSem);
}

/*
 *  ======== NVSI2C24C_control ========
 */
int_fast16_t NVSI2C24C_control(NVS_Handle handle, uint_fast16_t cmd, uintptr_t arg)
{
    //NVSI2C24C_HWAttrs const *hwAttrs;
    NVSI2C24C_Object *object;

    if (cmd != NVSI2C24C_CMD_MASS_ERASE) return (NVS_STATUS_UNDEFINEDCMD);

    //hwAttrs = handle->hwAttrs;
    object = handle->object;

    /* set protected global variables */
    I2CHandle = object->I2CHandle;

    return (extFlashMassErase(handle));
}

/*
 *  ======== NVSI2C24C_erase ========
 */
int_fast16_t NVSI2C24C_erase(NVS_Handle handle, size_t offset, size_t size)
{
    int_fast16_t status;

    SemaphoreP_pend(writeSem, SemaphoreP_WAIT_FOREVER);

    status = doErase(handle, offset, size);

    SemaphoreP_post(writeSem);

    return (status);
}

/*
 *  ======== NVSI2C24C_getAttrs ========
 */
void NVSI2C24C_getAttrs(NVS_Handle handle, NVS_Attrs *attrs)
{
    NVSI2C24C_HWAttrs const *hwAttrs;

    hwAttrs = handle->hwAttrs;

    /* FlashSectorSizeGet() returns the size of a flash sector in bytes. */
    attrs->regionBase  = NVS_REGION_NOT_ADDRESSABLE;
    attrs->regionSize  = hwAttrs->regionSize;
    attrs->sectorSize  = hwAttrs->sectorSize;
}

/*
 *  ======== NVSI2C24C_init ========
 */
void NVSI2C24C_init()
{
    unsigned int key;
    SemaphoreP_Handle sem;

    I2C_init();

    /* speculatively create a binary semaphore for thread safety */
    sem = SemaphoreP_createBinary(1);
    /* sem == NULL will be detected in 'open' */

    key = HwiP_disable();

    if (writeSem == NULL) {
        /* use the binary sem created above */
        writeSem = sem;
        HwiP_restore(key);
    }
    else {
        /* init already called */
        HwiP_restore(key);
        /* delete unused Semaphore */
        if (sem) {
            SemaphoreP_delete(sem);
        }
    }
}

/*
 *  ======== NVSI2C24C_lock =======
 */
int_fast16_t NVSI2C24C_lock(NVS_Handle handle, uint32_t timeout)
{
    if (SemaphoreP_pend(writeSem, timeout) != SemaphoreP_OK) {
        return (NVS_STATUS_TIMEOUT);
    }
    return (NVS_STATUS_SUCCESS);
}

/*
 *  ======== NVSI2C24C_open =======
 */
NVS_Handle NVSI2C24C_open(uint_least8_t index, NVS_Params *params)
{
    NVSI2C24C_Object *object;
    NVSI2C24C_HWAttrs const *hwAttrs;
    size_t sectorSize;
    NVS_Handle handle;
    I2C_Params I2CParams;

    /* Confirm that 'init' has successfully completed */
    if (writeSem == NULL) {
        NVSI2C24C_init();
        if (writeSem == NULL) {
            return (NULL);
        }
    }

    /* verify NVS region index */
    if (index >= NVS_count) {
        return (NULL);
    }

    SemaphoreP_pend(writeSem, SemaphoreP_WAIT_FOREVER);

    handle = &NVS_config[index];
    object = NVS_config[index].object;
    hwAttrs = NVS_config[index].hwAttrs;

    if (object->opened == true) {
        SemaphoreP_post(writeSem);
        return (NULL);
    }

    sectorSize = hwAttrs->sectorSize;
    object->sectorBaseMask = ~(sectorSize - 1);

    /* The regionBase must be aligned on a flaah page boundary */
    if ((hwAttrs->regionBaseOffset) & (sectorSize - 1)) {
        SemaphoreP_post(writeSem);
        return (NULL);
    }

    /* The region cannot be smaller than a sector size */
    if (hwAttrs->regionSize < sectorSize) {
        SemaphoreP_post(writeSem);
        return (NULL);
    }

    /* The region size must be a multiple of sector size */
    if (hwAttrs->regionSize != (hwAttrs->regionSize & object->sectorBaseMask)) {
        SemaphoreP_post(writeSem);
        return (NULL);
    }

    if (hwAttrs->I2CHandle) {
        /* use the provided I2C Handle */
        object->I2CHandle = *hwAttrs->I2CHandle;
    }
    else {
        if (hwAttrs->I2CIndex > MAX_I2C_INDEX) {
            SemaphoreP_post(writeSem);
            return (NULL);
        }
        /* Open I2C if this driver hasn't already opened this I2C instance */
        if (I2CHandles[hwAttrs->I2CIndex] == NULL) {
            I2C_Handle I2C;

            I2C_Params_init(&I2CParams);
            I2CParams.transferMode = I2C_MODE_BLOCKING;

            /* Attempt to open I2C. */
            I2C = I2C_open(hwAttrs->I2CIndex, &I2CParams);

            if (I2C == NULL) {
                SemaphoreP_post(writeSem);
                return (NULL);
            }

            I2CHandles[hwAttrs->I2CIndex] = I2C;
        }
        object->I2CHandle = I2CHandles[hwAttrs->I2CIndex];
        /* keep track of how many regions use the same I2C handle */
        I2CHandleUsers[hwAttrs->I2CIndex] += 1;
    }

    /* set protected global variables */
    I2CHandle = object->I2CHandle;
    object->opened = true;

    /* Put the part in standby mode */
    extFlashPowerStandby(handle);

    SemaphoreP_post(writeSem);

    return (handle);
}

/*
 *  ======== NVSI2C24C_read =======
 */
int_fast16_t NVSI2C24C_read(NVS_Handle handle, size_t offset, void *buffer,
        size_t bufferSize)
{
    NVSI2C24C_HWAttrs const *hwAttrs;
    int retval = NVS_STATUS_SUCCESS;

    hwAttrs = handle->hwAttrs;

    /* Validate offset and bufferSize */
    if (offset + bufferSize > hwAttrs->regionSize) {
        return (NVS_STATUS_INV_OFFSET);
    }

    /*
     *  Get exclusive access to the region.  We don't want someone
     *  else to erase the region while we are reading it.
     */
    SemaphoreP_pend(writeSem, SemaphoreP_WAIT_FOREVER);

    retval = doRead(handle, offset, buffer, bufferSize);

    SemaphoreP_post(writeSem);

    return (retval);
}

/*
 *  ======== NVSI2C24C_unlock =======
 */
void NVSI2C24C_unlock(NVS_Handle handle)
{
    SemaphoreP_post(writeSem);
}

/*
 *  ======== NVSI2C24C_write =======
 */
int_fast16_t NVSI2C24C_write(NVS_Handle handle, size_t offset, void *buffer,
                      size_t bufferSize, uint_fast16_t flags)
{
    NVSI2C24C_Object *object;
    NVSI2C24C_HWAttrs const *hwAttrs;
    size_t length, foffset;
    uint32_t status = true;
    uint8_t *srcBuf;
    int retval = NVS_STATUS_SUCCESS;
    uint8_t wbuf[4];

    hwAttrs = handle->hwAttrs;
    object = handle->object;

    /* Validate offset and bufferSize */
    if (offset + bufferSize > hwAttrs->regionSize) {
        return (NVS_STATUS_INV_OFFSET);
    }

    /* Get exclusive access to the Flash region */
    SemaphoreP_pend(writeSem, SemaphoreP_WAIT_FOREVER);

    /* set protected global variables */
    I2CHandle = object->I2CHandle;

    /* If erase is set, erase destination sector(s) first */
    if (flags & NVS_WRITE_ERASE) {
        length = bufferSize & object->sectorBaseMask;
        if (bufferSize & (~object->sectorBaseMask)) {
            length += hwAttrs->sectorSize;
        }

        retval = doErase(handle, offset & object->sectorBaseMask, length);
        if (retval != NVS_STATUS_SUCCESS) {
            SemaphoreP_post(writeSem);
            return (retval);
        }
    }
    else if (flags & NVS_WRITE_PRE_VERIFY) {
        if ((hwAttrs->verifyBuf == NULL) || (hwAttrs->verifyBufSize == 0)) {
            SemaphoreP_post(writeSem);
            return (NVS_STATUS_ERROR);
        }

        retval = doWriteVerify(handle, offset, buffer, bufferSize,
                     hwAttrs->verifyBuf, hwAttrs->verifyBufSize, true);

        if (retval != NVS_STATUS_SUCCESS) {
            SemaphoreP_post(writeSem);
            return (retval);
        }
    }

    srcBuf = buffer;
    length = bufferSize;
    foffset = (size_t)hwAttrs->regionBaseOffset + offset;

    while (length > 0)
    {
        size_t ilen; /* interim length per instruction */

        /* Wait till previous erase/program operation completes */
        int ret = extFlashWaitReady(handle);

        if (ret) {
            status = false;
            break;
        }

        ret = extFlashWriteEnable(handle);

        if (ret) {
            status = false;
            break;
        }

        ilen = I2CFLASH_PROGRAM_PAGE_SIZE - (foffset % I2CFLASH_PROGRAM_PAGE_SIZE);
        if (length < ilen) {
            ilen = length;
        }

        wbuf[0] = I2CFLASH_WRITE;
        wbuf[1] = (foffset >> 16) & 0xff;
        wbuf[2] = (foffset >> 8) & 0xff;
        wbuf[3] = foffset & 0xff;

        foffset += ilen;
        length -= ilen;

        if (extFlashI2CWrite(wbuf, sizeof(wbuf)) != NVS_STATUS_SUCCESS) {
            status = false;
            break;
        }

        if (extFlashI2CWrite(srcBuf, ilen) != NVS_STATUS_SUCCESS) {
            status = false;
            break;
        }

        srcBuf += ilen;
    }

    if (status == false) {
        retval = NVS_STATUS_ERROR;
    }
    else if (flags & NVS_WRITE_POST_VERIFY) {
        if ((hwAttrs->verifyBuf == NULL) || (hwAttrs->verifyBufSize == 0)) {
            SemaphoreP_post(writeSem);
            return (NVS_STATUS_ERROR);
        }

        retval = doWriteVerify(handle, offset, buffer, bufferSize,
                     hwAttrs->verifyBuf, hwAttrs->verifyBufSize, false);
    }

    SemaphoreP_post(writeSem);

    return (retval);
}

/*
 *  ======== doWriteVerify =======
 */
static int_fast16_t doWriteVerify(NVS_Handle handle, size_t offset, void *src,
           size_t srcBufSize, void *dst, size_t dstBufSize, bool preFlag)
{
    size_t i, j;
    uint8_t *srcBuf, *dstBuf;
    bool bad;
    int_fast16_t retval;

    srcBuf = src;
    dstBuf = dst;

    j = dstBufSize;

    for (i = 0; i < srcBufSize; i++, j++) {
        if (j == dstBufSize) {
            retval = doRead(handle, offset + i, dstBuf, j);
            if (retval != NVS_STATUS_SUCCESS) {
                break;
            }
            j = 0;
        }
        if (preFlag) {
            bad = srcBuf[i] != (srcBuf[i] & dstBuf[j]);
        }
        else {
            bad = srcBuf[i] != dstBuf[j];
        }
        if (bad) return (NVS_STATUS_INV_WRITE);
    }
    return (NVS_STATUS_SUCCESS);
}

/*
 *  ======== checkEraseRange ========
 */
static int_fast16_t checkEraseRange(NVS_Handle handle, size_t offset, size_t size)
{
    NVSI2C24C_Object   *object;
    NVSI2C24C_HWAttrs const *hwAttrs;

    object = handle->object;
    hwAttrs = handle->hwAttrs;

    if (offset != (offset & object->sectorBaseMask)) {
        return (NVS_STATUS_INV_ALIGNMENT);    /* poorly aligned start address */
    }

    if (offset >= hwAttrs->regionSize) {
        return (NVS_STATUS_INV_OFFSET);   /* offset is past end of region */
    }

    if (offset + size > hwAttrs->regionSize) {
        return (NVS_STATUS_INV_SIZE);     /* size is too big */
    }

    if (size != (size & object->sectorBaseMask)) {
        return (NVS_STATUS_INV_SIZE);     /* size is not a multiple of sector size */
    }

    return (NVS_STATUS_SUCCESS);
}

/*
 *  ======== doErase ========
 */
static int_fast16_t doErase(NVS_Handle handle, size_t offset, size_t size)
{
    NVSI2C24C_HWAttrs const *hwAttrs;
    NVSI2C24C_Object *object;
    uint32_t sectorBase;
    size_t sectorSize;
    int_fast16_t rangeStatus;
    uint8_t wbuf[4];

    /* sanity test the erase args */
    rangeStatus = checkEraseRange(handle, offset, size);

    if (rangeStatus != NVS_STATUS_SUCCESS) {
        return (rangeStatus);
    }

    hwAttrs = handle->hwAttrs;
    object = handle->object;

    /* set protected global variables */
    I2CHandle = object->I2CHandle;

    sectorBase = (uint32_t)hwAttrs->regionBaseOffset + offset;
    sectorSize = hwAttrs->sectorSize;

    /* assume that 4k sectors use SS ERASE, else Sector Erase */
    if (sectorSize == 4096) {
        wbuf[0] = I2CFLASH_SUBSECTOR_ERASE;
    }
    else {
        wbuf[0] = I2CFLASH_SECTOR_ERASE;
    }

    while (size) {
        /* Wait till previous erase/program operation completes */
        int ret = extFlashWaitReady(handle);
        if (ret) {
            return (NVS_STATUS_ERROR);
        }

        ret = extFlashWriteEnable(handle);
        if (ret) {
            return (NVS_STATUS_ERROR);
        }

        wbuf[1] = (sectorBase >> 16) & 0xff;
        wbuf[2] = (sectorBase >> 8) & 0xff;
        wbuf[3] = sectorBase & 0xff;

        if (extFlashI2CWrite(wbuf, sizeof(wbuf))) {
            return (NVS_STATUS_ERROR);
        }

        sectorBase += sectorSize;
        size -= sectorSize;
    }

    return (NVS_STATUS_SUCCESS);
}

/*
 *  ======== doRead =======
 */
static int_fast16_t doRead(NVS_Handle handle, size_t offset, void *buffer,
        size_t bufferSize)
{
    NVSI2C24C_Object *object;
    NVSI2C24C_HWAttrs const *hwAttrs;
    size_t loffset;
    uint8_t wbuf[4];
    int retval = NVS_STATUS_SUCCESS;

    hwAttrs = handle->hwAttrs;
    object = handle->object;

    /* set protected global variables */
    I2CHandle = object->I2CHandle;
    loffset = offset + hwAttrs->regionBaseOffset;

    /* Wait till previous erase/program operation completes */
    retval = extFlashWaitReady(handle);
    if (retval) {
        return (retval);
    }

    /*
     * I2C is driven with very low frequency (1MHz < 33MHz fR spec)
     * in this temporary implementation.
     * and hence it is not necessary to use fast read.
     */
    wbuf[0] = I2CFLASH_READ;
    wbuf[1] = (loffset >> 16) & 0xff;
    wbuf[2] = (loffset >> 8) & 0xff;
    wbuf[3] = loffset & 0xff;

    if (extFlashI2CWrite(wbuf, sizeof(wbuf))) {
        return (NVS_STATUS_ERROR);
    }

    retval = extFlashI2CRead(buffer, bufferSize);

    return (retval);
}

/*
 *  ======== extFlashPowerDown =======
 *  Issue power down command
 */
static int_fast16_t extFlashPowerDown(NVS_Handle nvsHandle)
{
    uint8_t cmd;
    int_fast16_t status;

    cmd = I2CFLASH_DP;
    status = extFlashI2CWrite(&cmd,sizeof(cmd));

    return (status);
}

/*
 *  ======== extFlashPowerStandby =======
 *  Issue standby command
 */
static int_fast16_t extFlashPowerStandby(NVS_Handle nvsHandle)
{
    uint8_t cmd;
    int_fast16_t status;

    cmd = I2CFLASH_RDP;
    status = extFlashI2CWrite(&cmd, sizeof(cmd));

    if (status == NVS_STATUS_SUCCESS) {
        status = extFlashWaitReady(nvsHandle);
    }

    return (status);
}

/*
 *  ======== extFlashMassErase =======
 *  Issue mass erase command
 */
static int_fast16_t extFlashMassErase(NVS_Handle nvsHandle)
{
    uint8_t cmd;
    int_fast16_t status;

    /* wait for previous operation to complete */
    if (extFlashWaitReady(nvsHandle)) {
        return (NVS_STATUS_ERROR);
    }

    cmd = I2CFLASH_MASS_ERASE;
    status = extFlashI2CWrite(&cmd,sizeof(cmd));

    if (status != NVS_STATUS_SUCCESS) {
        return (status);
    }

    /* wait for mass erase to complete */
    return (extFlashWaitReady(nvsHandle));
}

/*
 *  ======== extFlashWaitReady =======
 *  Wait for any previous job to complete.
 */
static int_fast16_t extFlashWaitReady(NVS_Handle nvsHandle)
{
    const uint8_t wbuf[1] = { I2CFLASH_READ_STATUS };
    int_fast16_t ret;
    uint8_t buf;

    for (;;) {
        extFlashI2CWrite(wbuf, sizeof(wbuf));
        ret = extFlashI2CRead(&buf,sizeof(buf));

        if (ret != NVS_STATUS_SUCCESS) {
            /* Error */
            return (ret);
        }
        if (!(buf & I2CFLASH_STATUS_BIT_BUSY)) {
            /* Now ready */
            break;
        }
    }

    return (NVS_STATUS_SUCCESS);
}

/*
 *  ======== extFlashWriteEnable =======
 *  Issue I2CFLASH_WRITE_ENABLE command
 */
static int_fast16_t extFlashWriteEnable(NVS_Handle nvsHandle)
{
    const uint8_t wbuf[] = { I2CFLASH_WRITE_ENABLE };
    int_fast16_t ret;

    ret = extFlashI2CWrite(wbuf,sizeof(wbuf));

    return (ret);
}

/*
 *  ======== extFlashI2CWrite =======
 */
static int_fast16_t extFlashI2CWrite(const uint8_t *buf, size_t len)
{
    I2C_Transaction masterTransaction;

    masterTransaction.readBuf  = NULL;

    /*
     * work around I2C transfer from address 0x0
     * transfer first byte from local buffer
     */
    if (buf == NULL) {
        uint8_t byte0;
        byte0 = *buf++;
        masterTransaction.writeCount  = 1;
        masterTransaction.writeBuf  = (void*)&byte0;
        if (!I2C_transfer(I2CHandle, &masterTransaction)) {
            return (NVS_STATUS_ERROR);
        }
        len = len - 1;
        if (len == 0) {
            return (NVS_STATUS_SUCCESS);
        }
    }

    masterTransaction.writeCount  = len;
    masterTransaction.writeBuf  = (void*)buf;

    return (I2C_transfer(I2CHandle, &masterTransaction) ? NVS_STATUS_SUCCESS : NVS_STATUS_ERROR);
}

/*
 *  ======== extFlashI2CRead =======
 */
static int_fast16_t extFlashI2CRead(uint8_t *buf, size_t len)
{
    I2C_Transaction masterTransaction;

    masterTransaction.writeBuf = NULL;

    /*
     * work around I2C transfer to address 0x0
     * transfer first byte into local buffer
     */
    if (buf == NULL) {
        uint8_t byte0;
        masterTransaction.writeCount  = 1;
        masterTransaction.readBuf  = (void*)&byte0;
        if (!I2C_transfer(I2CHandle, &masterTransaction)) {
            return (NVS_STATUS_ERROR);
        }
        *buf++ = byte0;
        len = len - 1;
        if (len == 0) {
            return (NVS_STATUS_SUCCESS);
        }
    }

    masterTransaction.writeCount = len;
    masterTransaction.readBuf = buf;

    return (I2C_transfer(I2CHandle, &masterTransaction) ? NVS_STATUS_SUCCESS : NVS_STATUS_ERROR);
}
