/*
 * NVSI2C24C.h
 *
 *  Created on: 5 Sep. 2018
 *      Author: lucas.oldfield
 */


/*!*****************************************************************************
 *  @file       NVSI2C24C.h
 *  @brief      Non-Volatile Storage driver implementation
 *              for I2C flash peripherals
 *
 *  # Overview #
 *
 *  The NVSI2C24C module allows you to manage I2C flash memory.
 *  This driver works with most 256 byte/page I2C flash memory devices
 *  such as:
 *
 *      Micron     24Cxx   family
 *
 *  The I2C flash commands used by this driver are as follows:
 *
 *  @code
 *  #define I2CFLASH_PAGE_WRITE       0x02 // Page Program (up to 256 bytes)
 *  #define I2CFLASH_READ             0x03 // Read Data
 *  #define I2CFLASH_READ_STATUS      0x05 // Read Status Register
 *  #define I2CFLASH_WRITE_ENABLE     0x06 // Write Enable
 *  #define I2CFLASH_SUBSECTOR_ERASE  0x20 // SubSector (4K bytes) Erase
 *  #define I2CFLASH_SECTOR_ERASE     0xD8 // Sector (usually 64K bytes) Erase
 *  #define I2CFLASH_RDP              0xAB // Release from Deep Power Down
 *  #define I2CFLASH_DP               0xB9 // Deep Power Down
 *  #define I2CFLASH_MASS_ERASE       0xC7 // Erase entire flash.
 *  @endcode
 *
 *  It is assumed that the I2C flash device used by this driver supports
 *  the byte programmability of the I2CFLASH_PAGE_WRITE command and that
 *  write page size is 256 bytes.
 *
 *  The NVS_erase() command assumes that regions with sectorSize = 4096 bytes
 *  are erased using the I2CFLASH_SUBSECTOR_ERASE command (0x20). Otherwise the
 *  I2CFLASH_SECTOR_ERASE command (0xD8) is used to erase the flash sector.
 *  It is up to the user to ensure that each region's sectorSize matches these
 *  sector erase rules.
 *
 * ## I2C Interface Management ##
 *
 *  For each managed flash region, a corresponding I2C instance must be
 *  provided to the NVSI2C24C driver.
 *
 *  The I2C instance can be opened and closed
 *  internally by the NVSI2C24C driver, or alternatively, a I2C handle can be
 *  provided to the NVSI2C24C driver, indicating that the I2C instance is being
 *  opened and closed elsewhere within the application. This mode is useful
 *  when the I2C bus is share by more than just the I2C flash device.
 *
 *  If the I2C instance is to be managed internally by the NVSI2C24C driver, a I2C
 *  instance index and bit rate must be configured in the region's HWAttrs.
 *  If the same I2C instance is referenced by multiple flash regions
 *  the driver will ensure that I2C_open() is invoked only once, and that
 *  I2C_close() will only be invoked when all flash regions using the I2C
 *  instance have been closed.
 *
 *  If the I2C bus that the I2C flash device is on is shared with other
 *  devices accessed by an application, then the I2C handle used to manage
 *  a I2C flash region can be provided in the region's HWAttrs "I2CHandle"
 *  field. Keep in mind that the "I2CHandle" field is a POINTER to a
 *  I2C Handle, NOT a I2C Handle. This allows the user to simply initialize
 *  this field with the name of the global variable used for the I2C handle.
 *  In this mode, the user MUST open the I2C instance prior to opening the NVS
 *  region instance so that the referenced I2CHandle is valid.
 *
 *  By default, the "I2CHandle" field is set to NULL, indicating that the user
 *  expects the NVS driver to open and close the I2C instance internally using
 *  the 'I2CIndex' and 'I2CBitRate' provided in the HWAttrs.
 */
#ifndef DRIVERS_NVS_NVSI2C24C_H_
#define DRIVERS_NVS_NVSI2C24C_H_

#include <stdint.h>
#include <stdbool.h>

#include <ti/drivers/I2C.h>

#if defined (__cplusplus)
extern "C" {
#endif

/*!
 *  @brief Command to perform mass erase of entire flash
 *
 *  As this command can erase flash memory outside the region associated
 *  with the NVS_Handle passed to the control command, the user must
 *  carefully orchestrate the use of the command.
 *
 *  Mass Erase is the only control command supported.
 */
#define NVSI2C24C_CMD_MASS_ERASE        (NVS_CMD_RESERVED + 0)

/*!
 *  @internal @brief NVS function pointer table
 *
 *  'NVSI2C24C_fxnTable' is a fully populated function pointer table
 *  that can be referenced in the NVS_config[] array entries.
 *
 *  Users can minimize their application code size by providing their
 *  own custom NVS function pointer table that contains only those APIs
 *  used by the application.
 */
extern const NVS_FxnTable NVSI2C24C_fxnTable;

/*!
 *  @brief      NVSI2C24C attributes
 *
 *  The 'regionBaseOffset' is the offset, in bytes, from the base of the
 *  I2C flash, of the flash region to be managed.
 *
 *  The 'regionSize' must be an integer multiple of the flash sector size.
 *
 *  The 'sectorSize' is I2C flash device specific. This parameter should
 *  correspond to the number of bytes erased when the
 *  'I2CFLASH_SUBSECTOR_ERASE' (0x20) command is issued to the device.
 *
 *  The 'verifyBuf' and 'verifyBufSize' parameters are used by the
 *  NVS_write() command when either 'NVS_WRITE_PRE_VERIFY' or
 *  'NVS_WRITE_POST_VERIFY' functions are requested in the 'flags'
 *  argument. The 'verifyBuf' is used to successively read back portions
 *  of the flash to compare with the data being written to it.
 *
 *  @code
 *  //
 *  // Only one region write operation is performed at a time
 *  // so a single verifyBuf can be shared by all the regions.
 *  //
 *  uint8_t verifyBuf[256];
 *
 *  NVSI2C24C_HWAttrs nvsI2CHWAttrs[2] = {
 *      //
 *      // region 0 is 1 flash sector in length.
 *      //
 *      {
 *          .regionBaseOffset = 0,
 *          .regionSize = 4096,
 *          .sectorSize = 4096,
 *          .verifyBuf = verifyBuf;
 *          .verifyBufSize = 256;
 *          .I2CHandle = NULL,
 *          .I2CIndex = 0,
 *          .I2CBitRate = 40000000,
 *          .I2CCsnGpioIndex = 12,
 *      },
 *      //
 *      // region 1 is 3 flash sectors in length.
 *      //
 *      {
 *          .regionBaseOffset = 4096,
 *          .regionSize = 4096 * 3,
 *          .sectorSize = 4096,
 *          .verifyBuf = verifyBuf;     // use shared verifyBuf
 *          .verifyBufSize = 256;
 *          .I2CHandle = NULL,
 *          .I2CIndex = 0,
 *          .I2CBitRate = 40000000,
 *          .I2CCsnGpioIndex = 12,
 *      }
 *  };
 *  @endcode
 */
typedef struct NVSI2C24C_HWAttrs {
    size_t      regionBaseOffset;   /*!< Offset from base of I2C flash */
    size_t      regionSize;         /*!< The size of the region in bytes */
    size_t      sectorSize;         /*!< Erase sector size */
    uint8_t     *verifyBuf;         /*!< Write Pre/Post verify buffer */
    size_t      verifyBufSize;      /*!< Write Pre/Post verify buffer size */
    I2C_Handle  *I2CHandle;         /*!< ptr to I2C handle if provided by user. */
    uint16_t    I2CIndex;           /*!< I2C instance index from Board file */
} NVSI2C24C_HWAttrs;

/*
 *  @brief      NVSI2C24C Object
 *
 *  The application must not access any member variables of this structure!
 */
typedef struct NVSI2C24C_Object {
    bool        opened;             /* Has this region been opened */
    I2C_Handle  I2CHandle;
    size_t      sectorBaseMask;
} NVSI2C24C_Object;

/*
 *  @cond NODOC
 *  NVSI2C24C driver public APIs
 */

extern void         NVSI2C24C_close(NVS_Handle handle);
extern int_fast16_t NVSI2C24C_control(NVS_Handle handle, uint_fast16_t cmd,
                        uintptr_t arg);
extern int_fast16_t NVSI2C24C_erase(NVS_Handle handle, size_t offset,
                        size_t size);
extern void         NVSI2C24C_getAttrs(NVS_Handle handle, NVS_Attrs *attrs);
extern void         NVSI2C24C_init();
extern int_fast16_t NVSI2C24C_lock(NVS_Handle handle, uint32_t timeout);
extern NVS_Handle   NVSI2C24C_open(uint_least8_t index, NVS_Params *params);
extern int_fast16_t NVSI2C24C_read(NVS_Handle handle, size_t offset,
                        void *buffer, size_t bufferSize);
extern void         NVSI2C24C_unlock(NVS_Handle handle);
extern int_fast16_t NVSI2C24C_write(NVS_Handle handle, size_t offset,
                        void *buffer, size_t bufferSize, uint_fast16_t flags);

/*! @endcond */

#if defined (__cplusplus)
}
#endif /* defined (__cplusplus) */


/** @}*/
#endif /* DRIVERS_NVS_NVSI2C24C_H_ */
